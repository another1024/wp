random

用了输入流的缓存机制，关闭文件后没有清空文件流，输入缓存与文件流重合构造uaf，格式化字符串泄露信息

easycalc

off-by-one制造unsortbin与fastbin重合，这时fastbin的地址指向main_arena

然后局部修改fastbin，让指针指向malloc_hook前面，然后unsortbin attack 攻击malloc_hook

最后通过pwnable.tw的calc的方法输入加号相对偏于one_gadget。

rsa

看线下赛的吧。

bus

memcpy的时候没限制长度，把数字当地址复制过去了。





脚本没了，写的有点简略了。 